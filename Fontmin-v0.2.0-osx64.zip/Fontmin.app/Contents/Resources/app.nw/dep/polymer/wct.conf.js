module.exports = {
  suites: ['test/runner.html'], 
};
